╔══════════════════════════════════════════╗
║         PIXEL — Desktop App              ║
║   made with love by Pixel for bot        ║
╚══════════════════════════════════════════╝

REQUIREMENTS
────────────
• Node.js 18 or newer  →  https://nodejs.org
• That's it!

HOW TO BUILD YOUR .EXE  (2 commands)
─────────────────────────────────────
1. Open a terminal in the "focusforge-desktop" folder

2. Install tools (one-time, takes ~1 min):
      npm install

3. Build the Windows installer:
      npm run dist

Done! Look in:  focusforge-desktop/release/
  • "Pixel Setup 1.0.0.exe"  →  installer (recommended)
  • "Pixel 1.0.0.exe"         →  portable, no install needed

FOLDER STRUCTURE
────────────────
pixel-desktop/
  dist/electron-web/    ← built web app (already done)
  focusforge-desktop/
    main.js             ← Electron entry point
    preload.js          ← Electron security bridge
    package.json        ← build config (electron-builder)
    README.txt          ← this file

NOTES
─────
• Your data is stored in IndexedDB on your PC — fully offline
• Backup: open Settings → Export Backup anytime
• To update the app, re-run "npm run dist" with new source files
